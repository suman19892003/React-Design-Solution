import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import { DashboardComponent  } from './dashboard/dashboard.component';

function App() {
  return (
    <Router>
        <Switch>
          <Route path="/">
            <DashboardComponent />
          </Route>
        </Switch>
    </Router>
  );
}

export default App;
