import React from 'react';

function StepBarComponent(props) {
  const list = props.formState || [];
  return (
    <div class="container">
      <ul class="progressbar">
        {list.map((value, index) => {
          return <li class={value.status === 'done' ? 'active' : ''} key={index}>{value.form}</li>;
        })}
      </ul>
    </div>
  );
}

export default StepBarComponent;
