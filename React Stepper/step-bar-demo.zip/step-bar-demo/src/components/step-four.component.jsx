import React from 'react';

export class StepFourComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
    };
  }

  componentDidMount() {
  }

  render() {
    const { formState } = this.props || [];
    const isComplete = formState.filter((item) => item.form === "form4" && item.status === "done") || [];
    return (
    <div
        onClick={() =>
          this.props.onFormUpdate({ form: "form4", status: "done" })
        }
        class={!!!isComplete.length ? 'steps' : 'steps-hide'}>
        form4
      </div>)
  }
}
