import React from "react";

export class StepOneComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() { }

  render() {
    const { formState } = this.props || [];
    const isComplete = formState.filter((item) => item.form === "form1" && item.status === "done") || [];
    return (
      <div
        onClick={() =>
          this.props.onFormUpdate({ form: "form1", status: "done" })
        }
        class={!!!isComplete.length ? 'steps' : 'steps-hide'}>
        form1
      </div>
    );
  }
}
