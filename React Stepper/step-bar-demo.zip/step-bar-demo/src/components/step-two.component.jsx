import React from "react";

export class StepTwoComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  render() {
    const { formState } = this.props || [];
    const isComplete = formState.filter((item) => item.form === "form2" && item.status === "done") || [];
    return (
      <div
        onClick={() =>
          this.props.onFormUpdate({ form: "form2", status: "done" })
        }
        class={!!!isComplete.length ? 'steps' : 'steps-hide'}
      >
        form2
      </div>
    );
  }
}
