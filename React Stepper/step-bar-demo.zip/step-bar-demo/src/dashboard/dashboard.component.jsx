import React from "react";
import StepBarComponent from "./../components/step-bar.component";
import { StepOneComponent } from "./../components/step-one.component";
import { StepTwoComponent } from "./../components/step-two.component";
import { StepThreeComponent } from "./../components/step-three.component";
import { StepFourComponent } from "./../components/step-four.component";

export class DashboardComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            formState: [],
            formList: ["form1", "form2", "form3", "form4"],
            index: 0,
        };
        this.formUpdate = this.formUpdate.bind(this);
    }

    componentDidMount() {
        //const form = [ 'form1', 'form2', 'form3', 'form4'];
        const formMap = this.state.formList.map((item) => {
            return { form: item, status: "un-touch" }; // 'un-touch', 'in-progress', 'Done'
        });

        this.setState(
            {
                formState: formMap,
            },
            () => { }
        );
    }

    formUpdate(event) {
        const _list = [...this.state.formState];
        const _formState = _list.map((item) => {
            if (event.form === item.form) {
                return { form: item.form, status: event.status };
            } else if (event.status === "done") {
                return item;
            } else {
                return { form: item.form, status: "un-touch" };
            }
        });
        const { index } = this.state;
        this.setState(
            {
                formState: [..._formState],
            },
            () => {
                this.setState({ index: index + 1 });
            }
        );
    }

    render() {
        const { formState, formList, index } = this.state;

        return (
            <div class="dashboard-container">
                <div class="d-header">
                    <header>
                        <h3>{formState && <StepBarComponent formState={formState} />}</h3>
                    </header>
                </div>
                <div class="dashboard">
                    {formList.includes("form1") && index < 4 && (
                        <StepOneComponent
                            onFormUpdate={(event) => this.formUpdate(event)}
                            formState={formState}
                        ></StepOneComponent>
                    )}
                    {formList.includes("form2") && index < 4 && (
                        <StepTwoComponent
                            onFormUpdate={(event) => this.formUpdate(event)}
                            formState={formState}
                        ></StepTwoComponent>
                    )}
                    {formList.includes("form3") && index < 4 && (
                        <StepThreeComponent
                            onFormUpdate={(event) => this.formUpdate(event)}
                            formState={formState}
                        ></StepThreeComponent>
                    )}
                    {formList.includes("form4") && index < 4 && (
                        <StepFourComponent
                            onFormUpdate={(event) => this.formUpdate(event)}
                            formState={formState}
                        ></StepFourComponent>
                    )}
                    {index > 3 && (
                        <div class="form-completed">
                            {" "}
                            <label>Completed!</label>{" "}
                        </div>
                    )}
                </div>
            </div>
        );
    }
}
